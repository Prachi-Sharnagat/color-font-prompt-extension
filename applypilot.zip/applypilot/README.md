# ApplyPilot - AI job-application copilot (Chrome extension + API)

Open any job posting, click the extension, and get:

* **Match score** between your resume and the job, with matched / missing skills and tips
* **Tailored cover letter** in one click (professional / friendly / concise)
* **Right-click "Answer this question with ApplyPilot"** on any application form field
* **Application tracker** (saved → applied → interview → offer / rejected)
* Free plan with a monthly AI quota; **Pro** unlocks more via subscription (Lemon Squeezy)

## Architecture

```
Chrome extension (MV3, React + TS + Vite)            FastAPI backend (Python 3.13)
┌──────────────────────────────┐   HTTPS + JWT    ┌─────────────────────────────────┐
│ content script  - reads job  │ ───────────────▶ │ /auth  register/login/google/   │
│ popup UI        - match, CL, │                  │        refresh (access+refresh) │
│                   tracker    │                  │ /resumes  upload PDF/text       │
│ service worker  - right-click│ ◀─────────────── │ /ai       match, cover-letter,  │
│                   answers    │                  │           answer  (quota+rate   │
└──────────────────────────────┘                  │           limit, prompt-safe)   │
                                                  │ /applications  tracker CRUD     │
                                                  │ /billing/webhook  (HMAC, idem-  │
                                                  │           potent) → plan=pro    │
                                                  └───────┬───────────┬─────────────┘
                                                   PostgreSQL        Redis (rate limits)
                                                          LLM provider (Claude API)
```

Key design choices (good interview talking points):

* **Auth**: bcrypt passwords, short-lived access JWT + refresh JWT with type checks, Google sign-in via `chrome.identity` verified server-side; extension refreshes tokens transparently with a single shared in-flight refresh.
* **Cost control**: every AI call is a `usage_events` row → monthly plan quota (HTTP 402 → upgrade prompt) plus a per-minute sliding-window limit (Redis, in-memory fallback) → HTTP 429.
* **Billing**: Lemon Squeezy webhook verified with HMAC-SHA256, idempotent via a unique event-id table, maps subscription events to `plan`.
* **AI safety**: provider interface (Claude or deterministic mock for tests/dev); user/page text is delimited and treated as untrusted data (prompt-injection hardening); prompts forbid inventing experience.
* **Privacy**: resume text only leaves the device when the user presses an AI button; `DELETE /me` erases all data.
* **Ops**: Dockerfile (non-root, healthcheck), docker-compose with Postgres + Redis, request-ID logging, `/health`, CI on GitHub Actions, 10 API tests (auth, tenant isolation, quota, webhook signature/idempotency, account erasure).

## Run locally

```bash
# 1. Backend (SQLite + mock AI, zero config)
cd backend
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload                           # http://localhost:8000/docs
pytest -q

# 2. Extension
cd ../extension
npm install
npm run build                                           # outputs dist/
```
Load it: Chrome → `chrome://extensions` → Developer mode → **Load unpacked** → select `extension/dist`.

Real AI: copy `backend/.env.example` to `backend/.env`, set `AI_PROVIDER=anthropic` and `ANTHROPIC_API_KEY`.
Full stack: `docker compose up --build` (after creating `backend/.env`).

## Project layout

```
backend/app/{routers,services}  API, AI provider, quota, resume parser
backend/tests                   pytest suite
extension/src                   content.ts, background.ts, popup components
docs/LAUNCH.md                  deploy + Chrome Web Store + selling checklist
docs/PRIVACY_POLICY.md          template (required by the Web Store)
docs/STORE_LISTING.md           listing copy + permission justifications
```

## Resume bullets (fill in real numbers once you have them)

* Built and shipped **ApplyPilot**, an AI job-application Chrome extension (React/TypeScript, Manifest V3) with a **FastAPI + PostgreSQL + Redis** backend, published on the Chrome Web Store.
* Designed JWT auth (access/refresh, Google OAuth), per-plan AI usage quotas and Redis sliding-window rate limiting to keep LLM costs bounded.
* Integrated the Claude API for resume-job matching and cover-letter generation with prompt-injection hardening; integrated **Lemon Squeezy** subscriptions via signed, idempotent webhooks.
* Containerized with Docker, CI via GitHub Actions; **[N] users / [N] paying subscribers** in the first [N] weeks. *(Only add numbers that are true.)*
