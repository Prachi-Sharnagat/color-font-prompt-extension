# Chrome Web Store listing copy

**Name**: ApplyPilot - AI Job Application Copilot
**Summary (≤132 chars)**: See how well your resume matches any job, generate tailored cover letters and answers, and track every application.
**Category**: Productivity
**Single purpose**: Help users evaluate and apply to the job posting they are viewing and track their applications.

**Description**
Stop guessing whether a job is worth your time. ApplyPilot reads the job posting you're viewing (only when you click it) and shows:
- Resume match score with the skills you have and the ones you're missing
- A tailored cover letter in seconds, using only facts from your resume
- Right-click any application question → AI-drafted answer filled into the field
- A simple tracker from saved to offer
Works on LinkedIn, Indeed, Naukri and any site where you select the job text. Free plan included; Pro for heavy job hunts.
We never auto-apply, crawl sites, or sell your data.

## Permission justifications
- **storage**: keep your sign-in session on this device.
- **activeTab + scripting**: read the job posting on the tab you click the extension on, on sites outside the three built-in ones.
- **contextMenus**: the "Answer this question with ApplyPilot" right-click action.
- **Host permission (our API)**: send your request to the ApplyPilot server.
- **Content script on linkedin/indeed/naukri.com**: detect the job title, company and description on those pages.
- **identity** (only if Google sign-in is enabled): sign in with Google.
