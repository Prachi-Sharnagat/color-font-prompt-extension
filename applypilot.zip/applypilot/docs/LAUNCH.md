# Launch checklist

## 1. Deploy the backend (≈ 1 hour)
* **API**: Render, Railway or Fly.io from `backend/Dockerfile`. **DB**: Neon/Supabase Postgres. **Redis**: Upstash.
* Set env vars from `backend/.env.example`: `ENVIRONMENT=prod`, a strong `JWT_SECRET` (`openssl rand -hex 32`), `AI_PROVIDER=anthropic`, `ANTHROPIC_API_KEY`, `DATABASE_URL`, `REDIS_URL`.
* HTTPS is mandatory. Before real users: add Alembic migrations (the app uses `create_all` for zero-config dev) and set a monthly spend limit on your AI provider key.
* Set `CORS_ORIGINS=chrome-extension://<your-extension-id>` once you have the ID.

## 2. Payments
* Create a Lemon Squeezy store + a subscription product (e.g. Pro ₹/$ per month). It is a merchant of record (handles VAT/GST). **Check payout support for India on their site before committing.**
* Webhook URL: `https://<api>/billing/webhook`, events: `subscription_created/expired/cancelled/resumed/payment_success`. Put the signing secret in `LEMONSQUEEZY_WEBHOOK_SECRET`; set `CHECKOUT_URL` to the product's buy link.
* Test end-to-end in Lemon Squeezy test mode first.

## 3. Configure & build the extension
* `extension/.env`: `VITE_API_URL=https://<api>` (and `VITE_GOOGLE_CLIENT_ID` if you want Google sign-in).
* `npm run zip` → `extension/applypilot-extension.zip`.

## 4. Chrome Web Store
* Register at the Chrome Web Store developer dashboard (one-time US$5 fee), upload the zip.
* Needs: 128px icon (included), at least one 1280×800 screenshot, the listing text in `STORE_LISTING.md`, a **public privacy-policy URL** (host `PRIVACY_POLICY.md` on GitHub Pages/Notion), single-purpose statement and permission justifications.
* Review usually takes from a day to a few weeks. Fix feedback and resubmit.
* With Google sign-in: after the first upload copy the extension ID, create the OAuth client (type "Chrome extension") with it, and add the ID to CORS.

## 5. Risks to know about
* **Site terms**: LinkedIn/Indeed/Naukri restrict automation and scraping. ApplyPilot only reads the page the user is viewing, on click, and never auto-applies or crawls. Keep it that way, and don't market it as an "auto-apply bot".
* **Selectors break** when sites redesign. JSON-LD and "select the text" fallbacks exist; budget time for maintenance.
* Never invent resume content: the prompts forbid it; keep it that way for user trust.
* Handle personal data as promised in the privacy policy (resumes are sensitive).

## 6. Getting the first real users
* Post a demo GIF on r/developersIndia, r/jobs, LinkedIn, Product Hunt; offer a free Pro month to the first 50 users in exchange for feedback.
* Add a feedback link in the popup, watch `usage_events` to see which feature people actually use.
