# ApplyPilot Privacy Policy
*Last updated: [DATE]. Replace bracketed items before publishing.*

**What we collect**: your email address (or Google account email), the resumes you upload (extracted text), the job details of pages you analyze when you press an AI button, your saved applications, and counts of AI actions used.

**What we do with it**: to provide the features you ask for (match score, cover letters, answers, tracker) and to enforce plan limits. Resume and job text are sent to our AI provider ([Anthropic]) only to generate the result you requested. We do not sell your data, use it for advertising, or read your browsing history. The extension reads a page only when you click it or use the context-menu action.

**Payments** are handled by [Lemon Squeezy]; we do not receive card details.

**Storage & retention**: data is stored on [hosting provider/region] and kept until you delete it. In Settings → Delete account (or by emailing [contact email]) all your data is permanently erased.

**Security**: HTTPS in transit, hashed passwords, access limited to the operator.

**Children**: not intended for users under 16.

**Contact**: [your name / email]
