from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, EmailStr, Field

Status = Literal["saved", "applied", "interview", "offer", "rejected"]


class RegisterIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)


class LoginIn(BaseModel):
    email: EmailStr
    password: str


class GoogleIn(BaseModel):
    access_token: str


class RefreshIn(BaseModel):
    refresh_token: str


class TokenOut(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"


class QuotaOut(BaseModel):
    used: int
    limit: int
    resets_at: datetime


class MeOut(BaseModel):
    id: int
    email: EmailStr
    plan: str
    quota: QuotaOut
    checkout_url: str


class ResumeOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    is_default: bool
    created_at: datetime
    preview: str = ""


class ResumeTextIn(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    text: str = Field(min_length=50, max_length=60000)


class JobIn(BaseModel):
    title: str = Field(max_length=300)
    company: str = Field(default="", max_length=200)
    description: str = Field(min_length=30, max_length=20000)
    url: str = Field(default="", max_length=1000)
    resume_id: int | None = None


class MatchOut(BaseModel):
    score: int
    matched_skills: list[str]
    missing_skills: list[str]
    summary: str
    tips: list[str]


class CoverLetterIn(JobIn):
    tone: Literal["professional", "friendly", "concise"] = "professional"


class CoverLetterOut(BaseModel):
    text: str


class AnswerIn(BaseModel):
    question: str = Field(min_length=3, max_length=1000)
    title: str = Field(default="", max_length=300)
    company: str = Field(default="", max_length=200)
    description: str = Field(default="", max_length=20000)
    resume_id: int | None = None


class AnswerOut(BaseModel):
    text: str


class ApplicationIn(BaseModel):
    company: str = Field(max_length=200)
    title: str = Field(max_length=300)
    url: str = Field(default="", max_length=1000)
    status: Status = "saved"
    match_score: int | None = Field(default=None, ge=0, le=100)
    notes: str = Field(default="", max_length=5000)


class ApplicationPatch(BaseModel):
    company: str | None = Field(default=None, max_length=200)
    title: str | None = Field(default=None, max_length=300)
    status: Status | None = None
    match_score: int | None = Field(default=None, ge=0, le=100)
    notes: str | None = Field(default=None, max_length=5000)


class ApplicationOut(ApplicationIn):
    model_config = ConfigDict(from_attributes=True)
    id: int
    created_at: datetime
    updated_at: datetime
