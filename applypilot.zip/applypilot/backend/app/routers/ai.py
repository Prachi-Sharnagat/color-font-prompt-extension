from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import get_db
from ..deps import current_user
from ..models import Resume, User
from ..schemas import AnswerIn, AnswerOut, CoverLetterIn, CoverLetterOut, JobIn, MatchOut
from ..services import quota
from ..services.ai import get_provider

router = APIRouter(prefix="/ai", tags=["ai"])


def _resume_text(db: Session, user: User, resume_id: int | None) -> str:
    q = select(Resume).where(Resume.user_id == user.id)
    q = q.where(Resume.id == resume_id) if resume_id else q.where(Resume.is_default.is_(True))
    r = db.scalar(q)
    if not r:
        raise HTTPException(400, "Add a resume first (or pick a valid one).")
    return r.text


@router.post("/match", response_model=MatchOut)
def match(body: JobIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    quota.enforce_ai_limits(db, user)
    resume = _resume_text(db, user, body.resume_id)
    result = get_provider().match(resume, f"{body.title}\n{body.description}")
    quota.record_usage(db, user, "match")
    return MatchOut(
        score=result.get("score", 0),
        matched_skills=result.get("matched_skills", []),
        missing_skills=result.get("missing_skills", []),
        summary=result.get("summary", ""),
        tips=result.get("tips", []),
    )


@router.post("/cover-letter", response_model=CoverLetterOut)
def cover_letter(body: CoverLetterIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    quota.enforce_ai_limits(db, user)
    resume = _resume_text(db, user, body.resume_id)
    text = get_provider().cover_letter(resume, body.description, body.title, body.company, body.tone)
    quota.record_usage(db, user, "cover_letter")
    return CoverLetterOut(text=text)


@router.post("/answer", response_model=AnswerOut)
def answer(body: AnswerIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    quota.enforce_ai_limits(db, user)
    resume = _resume_text(db, user, body.resume_id)
    text = get_provider().answer(resume, f"{body.title} {body.company}\n{body.description}", body.question)
    quota.record_usage(db, user, "answer")
    return AnswerOut(text=text)
