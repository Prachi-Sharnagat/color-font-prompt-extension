"""Lemon Squeezy webhook. Verifies the HMAC signature, is idempotent, and flips the user's plan.
Configure a webhook in the Lemon Squeezy dashboard pointing at POST /billing/webhook and pass
the user id via checkout custom data (checkout[custom][user_id]) - /me already builds that URL."""

import hashlib
import hmac
import json

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from ..config import get_settings
from ..db import get_db
from ..models import User, WebhookEvent

router = APIRouter(prefix="/billing", tags=["billing"])

PRO_EVENTS = {"subscription_created", "subscription_resumed", "subscription_unpaused", "subscription_payment_success"}
FREE_EVENTS = {"subscription_expired", "subscription_cancelled"}


@router.post("/webhook")
async def webhook(request: Request, db: Session = Depends(get_db)):
    secret = get_settings().lemonsqueezy_webhook_secret
    raw = await request.body()
    if not secret:
        raise HTTPException(503, "Billing not configured.")
    expected = hmac.new(secret.encode(), raw, hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, request.headers.get("X-Signature", "")):
        raise HTTPException(401, "Bad signature.")

    payload = json.loads(raw)
    meta = payload.get("meta", {})
    name = meta.get("event_name", "")
    data = payload.get("data", {})
    event_id = f"{name}:{data.get('id')}:{data.get('attributes', {}).get('updated_at', '')}"

    try:
        db.add(WebhookEvent(event_id=event_id))
        db.commit()
    except IntegrityError:
        db.rollback()
        return {"ok": True, "duplicate": True}

    user_id = (meta.get("custom_data") or {}).get("user_id")
    user = db.get(User, int(user_id)) if user_id else None
    if user is None:
        return {"ok": True, "ignored": "unknown user"}

    if name in PRO_EVENTS:
        user.plan = "pro"
        user.lemon_customer_id = str(data.get("attributes", {}).get("customer_id", "")) or user.lemon_customer_id
    elif name in FREE_EVENTS:
        user.plan = "free"
    db.commit()
    return {"ok": True}
