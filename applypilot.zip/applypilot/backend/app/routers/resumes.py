from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import get_settings
from ..db import get_db
from ..deps import current_user
from ..models import Resume, User
from ..schemas import ResumeOut, ResumeTextIn
from ..services.resume_parser import extract_text

router = APIRouter(prefix="/resumes", tags=["resumes"])
MAX_RESUMES = 5


def _out(r: Resume) -> ResumeOut:
    return ResumeOut(id=r.id, name=r.name, is_default=r.is_default, created_at=r.created_at, preview=r.text[:200])


def _create(db: Session, user: User, name: str, text: str) -> Resume:
    existing = db.scalars(select(Resume).where(Resume.user_id == user.id)).all()
    if len(existing) >= MAX_RESUMES:
        raise HTTPException(400, f"You can store up to {MAX_RESUMES} resumes.")
    r = Resume(user_id=user.id, name=name, text=text, is_default=not existing)
    db.add(r)
    db.commit()
    return r


@router.get("", response_model=list[ResumeOut])
def list_resumes(user: User = Depends(current_user), db: Session = Depends(get_db)):
    rows = db.scalars(select(Resume).where(Resume.user_id == user.id).order_by(Resume.created_at.desc())).all()
    return [_out(r) for r in rows]


@router.post("/text", response_model=ResumeOut, status_code=201)
def create_from_text(body: ResumeTextIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    return _out(_create(db, user, body.name, body.text))


@router.post("/upload", response_model=ResumeOut, status_code=201)
async def upload(file: UploadFile = File(...), user: User = Depends(current_user), db: Session = Depends(get_db)):
    data = await file.read(get_settings().max_resume_bytes + 1)
    if len(data) > get_settings().max_resume_bytes:
        raise HTTPException(413, "File too large (max 5 MB).")
    text = extract_text(file.filename or "resume.pdf", data)
    return _out(_create(db, user, file.filename or "Resume", text))


@router.post("/{resume_id}/default", response_model=ResumeOut)
def set_default(resume_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    rows = db.scalars(select(Resume).where(Resume.user_id == user.id)).all()
    target = next((r for r in rows if r.id == resume_id), None)
    if not target:
        raise HTTPException(404, "Resume not found.")
    for r in rows:
        r.is_default = r.id == resume_id
    db.commit()
    return _out(target)


@router.delete("/{resume_id}", status_code=204)
def delete(resume_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    r = db.get(Resume, resume_id)
    if not r or r.user_id != user.id:
        raise HTTPException(404, "Resume not found.")
    db.delete(r)
    db.commit()
