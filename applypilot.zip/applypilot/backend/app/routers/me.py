from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from ..config import get_settings
from ..db import get_db
from ..deps import current_user
from ..models import User
from ..schemas import MeOut, QuotaOut
from ..services import quota

router = APIRouter(tags=["me"])


@router.get("/me", response_model=MeOut)
def me(user: User = Depends(current_user), db: Session = Depends(get_db)):
    _, resets = quota.month_bounds()
    return MeOut(
        id=user.id,
        email=user.email,
        plan=user.plan,
        quota=QuotaOut(used=quota.usage_this_month(db, user), limit=quota.plan_limit(user), resets_at=resets),
        checkout_url=f"{get_settings().checkout_url}?checkout[email]={user.email}&checkout[custom][user_id]={user.id}",
    )


@router.delete("/me", status_code=204)
def delete_account(user: User = Depends(current_user), db: Session = Depends(get_db)):
    """GDPR-style erasure: removes the user and all their resumes/applications/usage."""
    db.delete(user)
    db.commit()
