from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import get_db
from ..deps import current_user
from ..models import Application, User
from ..schemas import ApplicationIn, ApplicationOut, ApplicationPatch

router = APIRouter(prefix="/applications", tags=["applications"])


def _get_owned(db: Session, user: User, app_id: int) -> Application:
    a = db.get(Application, app_id)
    if not a or a.user_id != user.id:
        raise HTTPException(404, "Application not found.")
    return a


@router.get("", response_model=list[ApplicationOut])
def list_applications(status: str | None = None, user: User = Depends(current_user), db: Session = Depends(get_db)):
    q = select(Application).where(Application.user_id == user.id).order_by(Application.updated_at.desc())
    if status:
        q = q.where(Application.status == status)
    return db.scalars(q).all()


@router.post("", response_model=ApplicationOut, status_code=201)
def create(body: ApplicationIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    # de-duplicate on URL so re-saving the same job just returns the existing row
    if body.url:
        dup = db.scalar(select(Application).where(Application.user_id == user.id, Application.url == body.url))
        if dup:
            return dup
    a = Application(user_id=user.id, **body.model_dump())
    db.add(a)
    db.commit()
    return a


@router.patch("/{app_id}", response_model=ApplicationOut)
def update(app_id: int, body: ApplicationPatch, user: User = Depends(current_user), db: Session = Depends(get_db)):
    a = _get_owned(db, user, app_id)
    for k, v in body.model_dump(exclude_unset=True).items():
        setattr(a, k, v)
    db.commit()
    return a


@router.delete("/{app_id}", status_code=204)
def delete(app_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    db.delete(_get_owned(db, user, app_id))
    db.commit()
