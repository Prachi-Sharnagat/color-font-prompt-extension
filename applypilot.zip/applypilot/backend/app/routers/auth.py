import httpx
import jwt
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import get_db
from ..models import User
from ..schemas import GoogleIn, LoginIn, RefreshIn, RegisterIn, TokenOut
from ..security import (create_access_token, create_refresh_token, decode_token,
                        hash_password, verify_password)

router = APIRouter(prefix="/auth", tags=["auth"])


def _tokens(user: User) -> TokenOut:
    return TokenOut(access_token=create_access_token(user.id), refresh_token=create_refresh_token(user.id))


@router.post("/register", response_model=TokenOut, status_code=201)
def register(body: RegisterIn, db: Session = Depends(get_db)):
    email = body.email.lower()
    if db.scalar(select(User).where(User.email == email)):
        raise HTTPException(409, "An account with this email already exists.")
    user = User(email=email, password_hash=hash_password(body.password))
    db.add(user)
    db.commit()
    return _tokens(user)


@router.post("/login", response_model=TokenOut)
def login(body: LoginIn, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.email == body.email.lower()))
    if not user or not user.password_hash or not verify_password(body.password, user.password_hash):
        raise HTTPException(401, "Incorrect email or password.")
    return _tokens(user)


@router.post("/google", response_model=TokenOut)
def google(body: GoogleIn, db: Session = Depends(get_db)):
    """Exchange a Google OAuth access token (from chrome.identity) for our own tokens.
    We verify it server-side by asking Google who it belongs to."""
    try:
        r = httpx.get(
            "https://www.googleapis.com/oauth2/v3/userinfo",
            headers={"Authorization": f"Bearer {body.access_token}"},
            timeout=10,
        )
    except httpx.HTTPError:
        raise HTTPException(502, "Could not reach Google.")
    if r.status_code != 200:
        raise HTTPException(401, "Invalid Google token.")
    info = r.json()
    if not info.get("email") or not info.get("email_verified"):
        raise HTTPException(401, "Google email not verified.")
    email = info["email"].lower()
    user = db.scalar(select(User).where(User.email == email))
    if not user:
        user = User(email=email)
        db.add(user)
        db.commit()
    return _tokens(user)


@router.post("/refresh", response_model=TokenOut)
def refresh(body: RefreshIn, db: Session = Depends(get_db)):
    try:
        user_id = decode_token(body.refresh_token, "refresh")
    except jwt.PyJWTError:
        raise HTTPException(401, "Invalid refresh token.")
    user = db.get(User, user_id)
    if not user:
        raise HTTPException(401, "User not found.")
    return _tokens(user)
