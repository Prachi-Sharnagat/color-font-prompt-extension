from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    app_name: str = "ApplyPilot API"
    environment: str = "dev"

    database_url: str = "sqlite:///./applypilot.db"
    redis_url: str = ""  # empty -> in-memory rate limiting (fine for a single instance)

    jwt_secret: str = "change-me-in-production"
    access_token_minutes: int = 30
    refresh_token_days: int = 30

    # AI provider: "anthropic" or "mock" (mock needs no API key; used in tests/dev)
    ai_provider: str = "mock"
    anthropic_api_key: str = ""
    ai_model: str = "claude-sonnet-5-5"

    # Free plan monthly AI quota; pro is effectively unlimited (fair-use cap)
    free_monthly_ai_calls: int = 10
    pro_monthly_ai_calls: int = 1000

    # Per-user burst limit (requests per minute) on AI endpoints
    ai_rate_limit_per_minute: int = 10

    # Billing (Lemon Squeezy works for sellers in India)
    lemonsqueezy_webhook_secret: str = ""
    checkout_url: str = "https://example.lemonsqueezy.com/checkout/buy/your-product"

    cors_origins: str = "*"  # tighten to chrome-extension://<id> in production
    max_resume_bytes: int = 5 * 1024 * 1024


@lru_cache
def get_settings() -> Settings:
    return Settings()
