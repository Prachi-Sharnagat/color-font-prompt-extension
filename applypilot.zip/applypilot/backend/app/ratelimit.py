"""Sliding-window rate limiter. Uses Redis when REDIS_URL is set (works across many
API instances), otherwise falls back to an in-process dict (single instance / tests)."""

import time
from collections import defaultdict, deque

from .config import get_settings

_local: dict[str, deque] = defaultdict(deque)
_redis = None


def _get_redis():
    global _redis
    url = get_settings().redis_url
    if not url:
        return None
    if _redis is None:
        import redis

        _redis = redis.Redis.from_url(url, decode_responses=True)
    return _redis


def allow(key: str, limit: int, window_seconds: int = 60) -> bool:
    r = _get_redis()
    now = time.time()
    if r is not None:
        rkey = f"rl:{key}"
        pipe = r.pipeline()
        pipe.zremrangebyscore(rkey, 0, now - window_seconds)
        pipe.zadd(rkey, {f"{now}": now})
        pipe.zcard(rkey)
        pipe.expire(rkey, window_seconds)
        count = pipe.execute()[2]
        return count <= limit

    q = _local[key]
    while q and q[0] <= now - window_seconds:
        q.popleft()
    if len(q) >= limit:
        return False
    q.append(now)
    return True


def reset_local() -> None:
    _local.clear()
