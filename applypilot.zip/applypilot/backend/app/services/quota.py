from datetime import datetime, timezone

from fastapi import HTTPException
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .. import ratelimit
from ..config import get_settings
from ..models import UsageEvent, User


def month_bounds(now: datetime | None = None) -> tuple[datetime, datetime]:
    now = now or datetime.now(timezone.utc)
    start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    end = start.replace(year=start.year + 1, month=1) if start.month == 12 else start.replace(month=start.month + 1)
    return start, end


def plan_limit(user: User) -> int:
    s = get_settings()
    return s.pro_monthly_ai_calls if user.plan == "pro" else s.free_monthly_ai_calls


def usage_this_month(db: Session, user: User) -> int:
    start, _ = month_bounds()
    return db.scalar(
        select(func.count(UsageEvent.id)).where(UsageEvent.user_id == user.id, UsageEvent.created_at >= start)
    ) or 0


def enforce_ai_limits(db: Session, user: User) -> None:
    """Raises 429 on burst-limit breach, 402 when the monthly plan quota is exhausted."""
    s = get_settings()
    if not ratelimit.allow(f"ai:{user.id}", s.ai_rate_limit_per_minute):
        raise HTTPException(429, "Too many requests, slow down a little.")
    if usage_this_month(db, user) >= plan_limit(user):
        raise HTTPException(402, "Monthly AI limit reached. Upgrade to Pro to continue.")


def record_usage(db: Session, user: User, kind: str) -> None:
    db.add(UsageEvent(user_id=user.id, kind=kind))
    db.commit()
