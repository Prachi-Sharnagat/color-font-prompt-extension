import os

# Must be set before the app is imported.
os.environ["DATABASE_URL"] = "sqlite:///./test.db"
os.environ["AI_PROVIDER"] = "mock"
os.environ["LEMONSQUEEZY_WEBHOOK_SECRET"] = "whsec_test"
os.environ["FREE_MONTHLY_AI_CALLS"] = "3"
os.environ["AI_RATE_LIMIT_PER_MINUTE"] = "100"

import pytest
from fastapi.testclient import TestClient

from app import ratelimit
from app.db import Base, engine
from app.main import app


@pytest.fixture(autouse=True)
def clean_db():
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    ratelimit.reset_local()
    yield


@pytest.fixture
def client():
    return TestClient(app)


def signup(client, email="a@example.com", password="password123"):
    r = client.post("/auth/register", json={"email": email, "password": password})
    assert r.status_code == 201, r.text
    return {"Authorization": f"Bearer {r.json()['access_token']}"}


@pytest.fixture
def auth(client):
    return signup(client)


RESUME = (
    "Software engineer with 3 years of experience building Python and FastAPI services, PostgreSQL, "
    "Docker, React and TypeScript front ends. Built a Chrome extension used by real users."
)
JOB = (
    "We are hiring a backend engineer. You will build Python FastAPI APIs, work with PostgreSQL, "
    "Kubernetes and Docker, and collaborate with React developers."
)
