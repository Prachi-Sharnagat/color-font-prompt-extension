import hashlib
import hmac
import json

from .conftest import JOB, RESUME, signup


def test_register_login_and_me(client):
    h = signup(client)
    assert client.post("/auth/register", json={"email": "a@example.com", "password": "password123"}).status_code == 409
    assert client.post("/auth/login", json={"email": "a@example.com", "password": "wrong-pass"}).status_code == 401
    r = client.post("/auth/login", json={"email": "A@Example.com", "password": "password123"})
    assert r.status_code == 200
    me = client.get("/me", headers=h).json()
    assert me["plan"] == "free" and me["quota"]["used"] == 0 and me["quota"]["limit"] == 3


def test_requires_auth(client):
    assert client.get("/me").status_code == 401
    assert client.get("/resumes", headers={"Authorization": "Bearer junk"}).status_code == 401


def test_refresh_token_cannot_be_used_as_access(client):
    r = client.post("/auth/register", json={"email": "b@example.com", "password": "password123"}).json()
    assert client.get("/me", headers={"Authorization": f"Bearer {r['refresh_token']}"}).status_code == 401
    assert client.post("/auth/refresh", json={"refresh_token": r["refresh_token"]}).status_code == 200
    assert client.post("/auth/refresh", json={"refresh_token": r["access_token"]}).status_code == 401


def test_resume_flow(client, auth):
    r = client.post("/resumes/text", json={"name": "Main", "text": RESUME}, headers=auth)
    assert r.status_code == 201 and r.json()["is_default"] is True
    assert client.post("/resumes/upload", files={"file": ("cv.txt", RESUME.encode())}, headers=auth).status_code == 201
    assert client.post("/resumes/upload", files={"file": ("cv.exe", b"x" * 100)}, headers=auth).status_code == 415
    assert len(client.get("/resumes", headers=auth).json()) == 2


def test_ai_requires_resume_then_scores(client, auth):
    body = {"title": "Backend Engineer", "description": JOB}
    assert client.post("/ai/match", json=body, headers=auth).status_code == 400
    client.post("/resumes/text", json={"name": "Main", "text": RESUME}, headers=auth)
    r = client.post("/ai/match", json=body, headers=auth)
    assert r.status_code == 200
    data = r.json()
    assert 0 < data["score"] <= 100
    assert "python" in data["matched_skills"] and "kubernetes" in data["missing_skills"]


def test_quota_enforced_and_pro_upgrade(client, auth):
    client.post("/resumes/text", json={"name": "Main", "text": RESUME}, headers=auth)
    body = {"title": "Backend Engineer", "description": JOB}
    for _ in range(3):
        assert client.post("/ai/match", json=body, headers=auth).status_code == 200
    assert client.post("/ai/match", json=body, headers=auth).status_code == 402
    assert client.get("/me", headers=auth).json()["quota"]["used"] == 3

    uid = client.get("/me", headers=auth).json()["id"]
    payload = json.dumps({
        "meta": {"event_name": "subscription_created", "custom_data": {"user_id": str(uid)}},
        "data": {"id": "1", "attributes": {"customer_id": 42, "updated_at": "t1"}},
    }).encode()
    sig = hmac.new(b"whsec_test", payload, hashlib.sha256).hexdigest()
    assert client.post("/billing/webhook", content=payload, headers={"X-Signature": sig}).status_code == 200
    assert client.get("/me", headers=auth).json()["plan"] == "pro"
    assert client.post("/ai/match", json=body, headers=auth).status_code == 200


def test_webhook_rejects_bad_signature_and_is_idempotent(client, auth):
    payload = json.dumps({"meta": {"event_name": "subscription_created"}, "data": {"id": "9", "attributes": {}}}).encode()
    assert client.post("/billing/webhook", content=payload, headers={"X-Signature": "bad"}).status_code == 401
    sig = hmac.new(b"whsec_test", payload, hashlib.sha256).hexdigest()
    assert client.post("/billing/webhook", content=payload, headers={"X-Signature": sig}).json().get("duplicate") is None
    assert client.post("/billing/webhook", content=payload, headers={"X-Signature": sig}).json()["duplicate"] is True


def test_applications_crud_isolation_and_dedup(client, auth):
    body = {"company": "Acme", "title": "Dev", "url": "https://jobs.example/1"}
    a = client.post("/applications", json=body, headers=auth).json()
    assert client.post("/applications", json=body, headers=auth).json()["id"] == a["id"]
    r = client.patch(f"/applications/{a['id']}", json={"status": "applied"}, headers=auth)
    assert r.json()["status"] == "applied"
    assert client.patch(f"/applications/{a['id']}", json={"status": "bogus"}, headers=auth).status_code == 422

    other = signup(client, "other@example.com")
    assert client.patch(f"/applications/{a['id']}", json={"status": "offer"}, headers=other).status_code == 404
    assert client.delete(f"/applications/{a['id']}", headers=other).status_code == 404
    assert client.get("/applications", headers=other).json() == []
    assert client.delete(f"/applications/{a['id']}", headers=auth).status_code == 204


def test_account_deletion_erases_data(client, auth):
    client.post("/resumes/text", json={"name": "Main", "text": RESUME}, headers=auth)
    assert client.delete("/me", headers=auth).status_code == 204
    assert client.get("/me", headers=auth).status_code == 401


def test_health(client):
    assert client.get("/health").json() == {"status": "ok"}
