import react from "@vitejs/plugin-react";
import { defineConfig, loadEnv, type Plugin } from "vite";

// Builds manifest.json from env so the API host + optional Google sign-in are configured in one place.
function manifestPlugin(env: Record<string, string>): Plugin {
  return {
    name: "applypilot-manifest",
    generateBundle() {
      const apiUrl = env.VITE_API_URL || "http://localhost:8000";
      const clientId = env.VITE_GOOGLE_CLIENT_ID;
      const manifest: Record<string, unknown> = {
        manifest_version: 3,
        name: "ApplyPilot - AI Job Application Copilot",
        short_name: "ApplyPilot",
        version: "1.0.0",
        description: "Score your resume against any job, generate tailored cover letters and answers, and track applications.",
        action: { default_popup: "popup.html", default_title: "ApplyPilot" },
        background: { service_worker: "background.js", type: "module" },
        permissions: ["storage", "activeTab", "scripting", "contextMenus", ...(clientId ? ["identity"] : [])],
        host_permissions: [`${new URL(apiUrl).origin}/*`],
        content_scripts: [
          {
            matches: ["https://*.linkedin.com/*", "https://*.indeed.com/*", "https://*.naukri.com/*"],
            js: ["content.js"],
            run_at: "document_idle",
          },
        ],
        icons: { "16": "icons/16.png", "48": "icons/48.png", "128": "icons/128.png" },
      };
      if (clientId) manifest.oauth2 = { client_id: clientId, scopes: ["openid", "email", "profile"] };
      this.emitFile({ type: "asset", fileName: "manifest.json", source: JSON.stringify(manifest, null, 2) });
    },
  };
}

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), "");
  return {
    plugins: [react(), manifestPlugin(env)],
    build: {
      outDir: "dist",
      emptyOutDir: true,
      sourcemap: mode === "development",
      rollupOptions: {
        input: { popup: "popup.html", background: "src/background.ts", content: "src/content.ts" },
        output: {
          entryFileNames: "[name].js",
          chunkFileNames: "assets/[name]-[hash].js",
          assetFileNames: "assets/[name]-[hash][extname]",
        },
      },
    },
  };
});
