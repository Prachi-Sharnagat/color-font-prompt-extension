import { useCallback, useEffect, useState } from "react";
import { api, getTokens, setTokens, type Me } from "./api";
import Login from "./components/Login";
import JobTab from "./components/JobTab";
import Tracker from "./components/Tracker";
import Settings from "./components/Settings";

type Tab = "job" | "tracker" | "settings";

export default function App() {
  const [me, setMe] = useState<Me | null>(null);
  const [state, setState] = useState<"loading" | "out" | "in">("loading");
  const [tab, setTab] = useState<Tab>("job");

  const loadMe = useCallback(async () => {
    if (!(await getTokens())) return setState("out");
    try {
      setMe(await api<Me>("/me"));
      setState("in");
    } catch {
      setState("out");
    }
  }, []);

  useEffect(() => {
    loadMe();
  }, [loadMe]);

  const logout = async () => {
    await setTokens(null);
    setMe(null);
    setState("out");
  };

  if (state === "loading") return <div className="center muted">Loading…</div>;
  if (state === "out") return <Login onDone={loadMe} />;

  const quotaPct = me ? Math.min(100, (me.quota.used / me.quota.limit) * 100) : 0;
  return (
    <div className="app">
      <header>
        <strong>ApplyPilot</strong>
        <span className={`badge ${me?.plan}`}>{me?.plan.toUpperCase()}</span>
      </header>
      <nav>
        {(["job", "tracker", "settings"] as Tab[]).map((t) => (
          <button key={t} className={tab === t ? "active" : ""} onClick={() => setTab(t)}>
            {t === "job" ? "This job" : t === "tracker" ? "Tracker" : "Settings"}
          </button>
        ))}
      </nav>
      {me && (
        <div className="quota" title="AI actions used this month">
          <div className="bar"><div style={{ width: `${quotaPct}%` }} /></div>
          <span>{me.quota.used}/{me.quota.limit} AI actions</span>
          {me.plan === "free" && <a href={me.checkout_url} target="_blank" rel="noreferrer">Upgrade</a>}
        </div>
      )}
      <main>
        {tab === "job" && <JobTab me={me!} onUsage={loadMe} />}
        {tab === "tracker" && <Tracker />}
        {tab === "settings" && <Settings me={me!} onLogout={logout} />}
      </main>
    </div>
  );
}
