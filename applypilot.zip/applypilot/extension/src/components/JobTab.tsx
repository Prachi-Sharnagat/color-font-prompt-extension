import { useEffect, useState } from "react";
import { ApiError, api, type Job, type Match, type Me, type Resume } from "../api";

async function readJob(): Promise<Job | null> {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id || !/^https?:/.test(tab.url ?? "")) return null;
  try {
    return await chrome.tabs.sendMessage(tab.id, { type: "GET_JOB" });
  } catch {
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
      return await chrome.tabs.sendMessage(tab.id, { type: "GET_JOB" });
    } catch {
      return null;
    }
  }
}

export default function JobTab({ me, onUsage }: { me: Me; onUsage: () => void }) {
  const [job, setJob] = useState<Job | null>(null);
  const [resumes, setResumes] = useState<Resume[]>([]);
  const [resumeId, setResumeId] = useState<number | undefined>();
  const [match, setMatch] = useState<Match | null>(null);
  const [letter, setLetter] = useState("");
  const [busy, setBusy] = useState("");
  const [msg, setMsg] = useState("");
  const [error, setError] = useState<ApiError | null>(null);

  useEffect(() => {
    readJob().then(setJob);
    api<Resume[]>("/resumes").then((r) => {
      setResumes(r);
      setResumeId(r.find((x) => x.is_default)?.id);
    });
  }, []);

  const guard = async (name: string, fn: () => Promise<void>) => {
    setBusy(name);
    setError(null);
    setMsg("");
    try {
      await fn();
      onUsage();
    } catch (e) {
      setError(e instanceof ApiError ? e : new ApiError(0, "Something went wrong."));
    } finally {
      setBusy("");
    }
  };

  if (resumes.length === 0)
    return <p className="muted">Add a resume in <b>Settings</b> first, then come back to a job page.</p>;
  if (!job || job.description.length < 30)
    return (
      <div>
        <p className="muted">Open a job posting (LinkedIn, Indeed, Naukri or any site). On other sites, select the job description text first.</p>
        <button onClick={() => readJob().then(setJob)}>Re-scan page</button>
      </div>
    );

  const payload = { title: job.title, company: job.company, description: job.description, url: job.url, resume_id: resumeId };

  return (
    <div className="stack">
      <div className="card">
        <b>{job.title}</b>
        <div className="muted">{job.company || "Company not detected"}</div>
      </div>

      {resumes.length > 1 && (
        <select value={resumeId} onChange={(e) => setResumeId(Number(e.target.value))}>
          {resumes.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
        </select>
      )}

      <div className="row">
        <button className="primary" disabled={!!busy} onClick={() => guard("match", async () => setMatch(await api<Match>("/ai/match", { json: payload })))}>
          {busy === "match" ? "Analyzing…" : "Match score"}
        </button>
        <button disabled={!!busy} onClick={() => guard("letter", async () => setLetter((await api<{ text: string }>("/ai/cover-letter", { json: payload })).text))}>
          {busy === "letter" ? "Writing…" : "Cover letter"}
        </button>
        <button disabled={!!busy} onClick={() => guard("save", async () => {
          await api("/applications", { json: { company: job.company || "Unknown", title: job.title, url: job.url, match_score: match?.score ?? null } });
          setMsg("Saved to tracker ✓");
        })}>Save</button>
      </div>

      {error && (
        <p className="error">
          {error.message}{" "}
          {error.status === 402 && <a href={me.checkout_url} target="_blank" rel="noreferrer">Upgrade to Pro</a>}
        </p>
      )}
      {msg && <p className="ok">{msg}</p>}

      {match && (
        <div className="card">
          <div className="score" style={{ ["--p" as string]: match.score }}><span>{match.score}</span></div>
          <p>{match.summary}</p>
          <Chips label="You have" items={match.matched_skills} kind="good" />
          <Chips label="Missing" items={match.missing_skills} kind="bad" />
          {match.tips.length > 0 && <ul>{match.tips.map((t) => <li key={t}>{t}</li>)}</ul>}
        </div>
      )}

      {letter && (
        <div className="card">
          <textarea value={letter} onChange={(e) => setLetter(e.target.value)} rows={10} />
          <button onClick={() => navigator.clipboard.writeText(letter).then(() => setMsg("Copied ✓"))}>Copy</button>
        </div>
      )}
      <p className="muted small">Tip: right-click any application question field → “Answer this question with ApplyPilot”.</p>
    </div>
  );
}

function Chips({ label, items, kind }: { label: string; items: string[]; kind: "good" | "bad" }) {
  if (!items.length) return null;
  return (
    <div className="chips">
      <span className="muted small">{label}</span>
      {items.map((s) => <span key={s} className={`chip ${kind}`}>{s}</span>)}
    </div>
  );
}
