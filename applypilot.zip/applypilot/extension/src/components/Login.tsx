import { useState } from "react";
import { ApiError, GOOGLE_ENABLED, authenticate, googleSignIn } from "../api";

export default function Login({ onDone }: { onDone: () => void }) {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const run = async (fn: () => Promise<void>) => {
    setBusy(true);
    setError("");
    try {
      await fn();
      onDone();
    } catch (e) {
      setError(e instanceof ApiError ? e.message : "Something went wrong.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="app login">
      <h1>ApplyPilot</h1>
      <p className="muted">Score your resume against any job and apply faster with AI.</p>
      <form onSubmit={(e) => { e.preventDefault(); run(() => authenticate(mode === "login" ? "/auth/login" : "/auth/register", { email, password })); }}>
        <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        <input type="password" placeholder="Password (min 8 chars)" value={password} onChange={(e) => setPassword(e.target.value)} minLength={8} required />
        <button className="primary" disabled={busy}>{mode === "login" ? "Log in" : "Create account"}</button>
      </form>
      {GOOGLE_ENABLED && <button disabled={busy} onClick={() => run(googleSignIn)}>Continue with Google</button>}
      {error && <p className="error">{error}</p>}
      <p className="muted small">
        {mode === "login" ? "New here? " : "Have an account? "}
        <a href="#" onClick={(e) => { e.preventDefault(); setMode(mode === "login" ? "register" : "login"); }}>
          {mode === "login" ? "Create an account" : "Log in"}
        </a>
      </p>
    </div>
  );
}
