import { useEffect, useState } from "react";
import { api, type Application, type Status } from "../api";

const STATUSES: Status[] = ["saved", "applied", "interview", "offer", "rejected"];

export default function Tracker() {
  const [items, setItems] = useState<Application[] | null>(null);
  const [filter, setFilter] = useState<Status | "all">("all");

  const load = () => api<Application[]>("/applications").then(setItems);
  useEffect(() => { load(); }, []);

  const setStatus = async (a: Application, status: Status) => {
    const updated = await api<Application>(`/applications/${a.id}`, { method: "PATCH", json: { status } });
    setItems((cur) => cur!.map((x) => (x.id === a.id ? updated : x)));
  };
  const remove = async (a: Application) => {
    await api(`/applications/${a.id}`, { method: "DELETE" });
    setItems((cur) => cur!.filter((x) => x.id !== a.id));
  };

  if (!items) return <p className="muted">Loading…</p>;
  const shown = items.filter((i) => filter === "all" || i.status === filter);
  const counts = (s: Status) => items.filter((i) => i.status === s).length;

  return (
    <div className="stack">
      <div className="chips">
        <button className={`chip ${filter === "all" ? "on" : ""}`} onClick={() => setFilter("all")}>All {items.length}</button>
        {STATUSES.map((s) => (
          <button key={s} className={`chip ${filter === s ? "on" : ""}`} onClick={() => setFilter(s)}>{s} {counts(s)}</button>
        ))}
      </div>
      {shown.length === 0 && <p className="muted">Nothing here yet. Save jobs from the “This job” tab.</p>}
      {shown.map((a) => (
        <div className="card" key={a.id}>
          <a href={a.url || undefined} target="_blank" rel="noreferrer"><b>{a.title}</b></a>
          <div className="muted">{a.company}{a.match_score != null && ` · ${a.match_score}% match`}</div>
          <div className="row">
            <select value={a.status} onChange={(e) => setStatus(a, e.target.value as Status)}>
              {STATUSES.map((s) => <option key={s}>{s}</option>)}
            </select>
            <button onClick={() => remove(a)} aria-label="Delete">✕</button>
          </div>
        </div>
      ))}
    </div>
  );
}
