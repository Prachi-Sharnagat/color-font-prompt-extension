import { useEffect, useRef, useState } from "react";
import { ApiError, api, type Me, type Resume } from "../api";

export default function Settings({ me, onLogout }: { me: Me; onLogout: () => void }) {
  const [resumes, setResumes] = useState<Resume[]>([]);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const file = useRef<HTMLInputElement>(null);

  const load = () => api<Resume[]>("/resumes").then(setResumes);
  useEffect(() => { load(); }, []);

  const run = async (fn: () => Promise<unknown>) => {
    setBusy(true);
    setError("");
    try {
      await fn();
      await load();
    } catch (e) {
      setError(e instanceof ApiError ? e.message : "Something went wrong.");
    } finally {
      setBusy(false);
    }
  };

  const upload = (f: File) => run(() => {
    const form = new FormData();
    form.append("file", f);
    return api("/resumes/upload", { form });
  });

  const deleteAccount = async () => {
    if (!confirm("Permanently delete your account and all your data? This cannot be undone.")) return;
    await api("/me", { method: "DELETE" });
    onLogout();
  };

  return (
    <div className="stack">
      <h3>Resumes</h3>
      {resumes.map((r) => (
        <div className="card" key={r.id}>
          <b>{r.name}</b> {r.is_default && <span className="chip on">default</span>}
          <div className="muted small">{r.preview}…</div>
          <div className="row">
            {!r.is_default && <button onClick={() => run(() => api(`/resumes/${r.id}/default`, { method: "POST" }))}>Make default</button>}
            <button onClick={() => run(() => api(`/resumes/${r.id}`, { method: "DELETE" }))}>Delete</button>
          </div>
        </div>
      ))}
      <input ref={file} type="file" accept=".pdf,.txt,.md" hidden onChange={(e) => e.target.files?.[0] && upload(e.target.files[0])} />
      <button className="primary" disabled={busy} onClick={() => file.current?.click()}>Upload resume (PDF or text)</button>
      {error && <p className="error">{error}</p>}

      <h3>Account</h3>
      <p className="muted">{me.email} · {me.plan} plan</p>
      <div className="row">
        <button onClick={onLogout}>Log out</button>
        <button className="danger" onClick={deleteAccount}>Delete account</button>
      </div>
      <p className="muted small">Your resume is sent to our server and an AI provider only when you press an AI button.</p>
    </div>
  );
}
