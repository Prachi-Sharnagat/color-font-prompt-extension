// Service worker: right-click -> "Answer with ApplyPilot" fills the focused application question.
import { api, type Job } from "./api";

const MENU_ID = "applypilot-answer";

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: MENU_ID,
    title: "Answer this question with ApplyPilot",
    contexts: ["editable", "selection"],
  });
});

function flash(text: string, color: string) {
  chrome.action.setBadgeBackgroundColor({ color });
  chrome.action.setBadgeText({ text });
  setTimeout(() => chrome.action.setBadgeText({ text: "" }), 4000);
}

async function ask<T>(tabId: number, message: object): Promise<T> {
  try {
    return await chrome.tabs.sendMessage(tabId, message);
  } catch {
    // Content script isn't on this page yet (non-job site): inject on demand (needs the user's click via activeTab).
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
    return await chrome.tabs.sendMessage(tabId, message);
  }
}

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== MENU_ID || !tab?.id) return;
  try {
    const job = await ask<Job>(tab.id, { type: "GET_JOB" });
    const focused = await ask<{ question: string }>(tab.id, { type: "GET_FOCUSED_QUESTION" });
    const question = info.selectionText?.trim() || focused.question;
    if (!question) return flash("?", "#d97706");

    flash("...", "#4f46e5");
    const { text } = await api<{ text: string }>("/ai/answer", {
      json: { question, title: job.title, company: job.company, description: job.description },
    });
    const res = await ask<{ ok: boolean }>(tab.id, { type: "FILL", text });
    flash(res.ok ? "OK" : "!", res.ok ? "#16a34a" : "#d97706");
  } catch (e: any) {
    flash(e?.status === 402 ? "PRO" : "ERR", "#dc2626");
  }
});
