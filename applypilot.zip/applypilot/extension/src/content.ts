// Content script. Reads the job on the current page and can fill text into the focused field.
// No runtime imports on purpose: it must build to one standalone file.
import type { Job } from "./api";

type SiteRule = { host: RegExp; title: string[]; company: string[]; description: string[] };

// Site markup changes often, so these are best-effort; JSON-LD and generic fallbacks follow.
const RULES: SiteRule[] = [
  {
    host: /linkedin\.com/,
    title: [".job-details-jobs-unified-top-card__job-title", ".top-card-layout__title", "h1"],
    company: [".job-details-jobs-unified-top-card__company-name", ".topcard__org-name-link"],
    description: ["#job-details", ".jobs-description__content", ".show-more-less-html__markup"],
  },
  {
    host: /indeed\.com/,
    title: ['[data-testid="jobsearch-JobInfoHeader-title"]', ".jobsearch-JobInfoHeader-title", "h1"],
    company: ['[data-testid="inlineHeader-companyName"]', '[data-company-name="true"]'],
    description: ["#jobDescriptionText"],
  },
  {
    host: /naukri\.com/,
    title: ["h1.styles_jd-header-title__rZwM1", "h1"],
    company: ["[class*='jd-header-comp-name'] a", "[class*='jd-header-comp-name']"],
    description: ["[class*='JDC__dang-inner-html']", ".job-desc"],
  },
];

const clean = (s: string | null | undefined) => (s ?? "").replace(/\s+/g, " ").trim();
const firstText = (sels: string[]) => {
  for (const s of sels) {
    const t = clean(document.querySelector(s)?.textContent);
    if (t) return t;
  }
  return "";
};
const stripHtml = (html: string) => clean(new DOMParser().parseFromString(html, "text/html").body.textContent);

function fromJsonLd(): Partial<Job> {
  for (const el of document.querySelectorAll('script[type="application/ld+json"]')) {
    try {
      const data = JSON.parse(el.textContent || "null");
      const nodes: any[] = Array.isArray(data) ? data : data?.["@graph"] ?? [data];
      const posting = nodes.find((n) => n && [].concat(n["@type"]).includes("JobPosting" as never));
      if (posting) {
        const org = posting.hiringOrganization;
        return {
          title: clean(posting.title),
          company: clean(typeof org === "string" ? org : org?.name),
          description: stripHtml(posting.description || ""),
        };
      }
    } catch {
      /* ignore malformed JSON-LD */
    }
  }
  return {};
}

function extractJob(): Job {
  const rule = RULES.find((r) => r.host.test(location.hostname));
  const ld = fromJsonLd();
  const selection = clean(window.getSelection()?.toString());

  let description = rule ? firstText(rule.description) : "";
  description ||= ld.description || "";
  // A manual selection always wins: lets users grab the exact text on any site.
  if (selection.length > 200) description = selection;
  if (!description) description = clean(document.querySelector("main")?.textContent).slice(0, 8000);

  return {
    title: (rule && firstText(rule.title)) || ld.title || clean(document.querySelector("h1")?.textContent) || document.title,
    company: (rule && firstText(rule.company)) || ld.company || "",
    description: description.slice(0, 15000),
    url: location.href.split("#")[0],
  };
}

// ---- focused-field helpers -------------------------------------------------------------
type Editable = HTMLInputElement | HTMLTextAreaElement | HTMLElement;
let lastField: Editable | null = null;

const isEditable = (el: Element | null): el is Editable =>
  !!el &&
  (el instanceof HTMLTextAreaElement ||
    (el instanceof HTMLInputElement && ["text", "search", ""].includes(el.type)) ||
    (el instanceof HTMLElement && el.isContentEditable));

document.addEventListener("focusin", (e) => {
  if (isEditable(e.target as Element)) lastField = e.target as Editable;
});

function fieldQuestion(el: Editable): string {
  const id = el.getAttribute("id");
  const label =
    (id && document.querySelector(`label[for="${CSS.escape(id)}"]`)?.textContent) ||
    el.closest("label")?.textContent ||
    el.getAttribute("aria-label") ||
    (el as HTMLInputElement).placeholder ||
    el.closest("[class*='question'], fieldset, .field")?.querySelector("label, legend")?.textContent ||
    "";
  return clean(label);
}

function fillField(el: Editable, text: string) {
  el.focus();
  if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) {
    // Use the native setter so React/Vue-controlled inputs notice the change.
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, "value")?.set?.call(el, text);
  } else {
    el.textContent = text;
  }
  el.dispatchEvent(new Event("input", { bubbles: true }));
  el.dispatchEvent(new Event("change", { bubbles: true }));
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === "GET_JOB") {
    sendResponse(extractJob());
  } else if (msg?.type === "GET_FOCUSED_QUESTION") {
    sendResponse({ question: lastField ? fieldQuestion(lastField) : "" });
  } else if (msg?.type === "FILL") {
    const ok = !!lastField && document.contains(lastField);
    if (ok) fillField(lastField!, String(msg.text ?? ""));
    sendResponse({ ok });
  }
  return false;
});
