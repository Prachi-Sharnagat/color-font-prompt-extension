export const API_URL: string = import.meta.env.VITE_API_URL || "http://localhost:8000";
export const GOOGLE_ENABLED = Boolean(import.meta.env.VITE_GOOGLE_CLIENT_ID);

export type Tokens = { access_token: string; refresh_token: string };
export type Quota = { used: number; limit: number; resets_at: string };
export type Me = { id: number; email: string; plan: "free" | "pro"; quota: Quota; checkout_url: string };
export type Resume = { id: number; name: string; is_default: boolean; preview: string };
export type Job = { title: string; company: string; description: string; url: string };
export type Match = { score: number; matched_skills: string[]; missing_skills: string[]; summary: string; tips: string[] };
export type Status = "saved" | "applied" | "interview" | "offer" | "rejected";
export type Application = {
  id: number;
  company: string;
  title: string;
  url: string;
  status: Status;
  match_score: number | null;
  notes: string;
  updated_at: string;
};

export class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

export const getTokens = async (): Promise<Tokens | null> => (await chrome.storage.local.get("tokens")).tokens ?? null;
export const setTokens = (tokens: Tokens | null) =>
  tokens ? chrome.storage.local.set({ tokens }) : chrome.storage.local.remove("tokens");

async function send(path: string, init: RequestInit, token?: string): Promise<Response> {
  const headers = new Headers(init.headers);
  if (token) headers.set("Authorization", `Bearer ${token}`);
  try {
    return await fetch(`${API_URL}${path}`, { ...init, headers });
  } catch {
    throw new ApiError(0, "Can't reach the ApplyPilot server. Check your connection.");
  }
}

async function errorMessage(res: Response): Promise<string> {
  try {
    const body = await res.json();
    if (typeof body.detail === "string") return body.detail;
    if (Array.isArray(body.detail)) return body.detail.map((d: { msg: string }) => d.msg).join(", ");
  } catch {
    /* fall through */
  }
  return `Request failed (${res.status})`;
}

let refreshing: Promise<Tokens | null> | null = null;

async function refresh(tokens: Tokens): Promise<Tokens | null> {
  // Share one in-flight refresh between concurrent requests.
  refreshing ??= (async () => {
    const res = await send("/auth/refresh", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ refresh_token: tokens.refresh_token }),
    });
    if (!res.ok) {
      await setTokens(null);
      return null;
    }
    const fresh: Tokens = await res.json();
    await setTokens(fresh);
    return fresh;
  })().finally(() => (refreshing = null));
  return refreshing;
}

type Opts = { method?: string; json?: unknown; form?: FormData };

export async function api<T>(path: string, opts: Opts = {}): Promise<T> {
  const init: RequestInit = { method: opts.method ?? (opts.json || opts.form ? "POST" : "GET") };
  if (opts.json !== undefined) {
    init.body = JSON.stringify(opts.json);
    init.headers = { "Content-Type": "application/json" };
  } else if (opts.form) {
    init.body = opts.form;
  }

  let tokens = await getTokens();
  let res = await send(path, init, tokens?.access_token);
  if (res.status === 401 && tokens) {
    tokens = await refresh(tokens);
    if (tokens) res = await send(path, init, tokens.access_token);
  }
  if (!res.ok) throw new ApiError(res.status, await errorMessage(res));
  return res.status === 204 ? (undefined as T) : res.json();
}

export async function authenticate(path: "/auth/login" | "/auth/register" | "/auth/google", json: unknown) {
  const tokens = await api<Tokens>(path, { json });
  await setTokens(tokens);
}

export function googleSignIn(): Promise<void> {
  return new Promise((resolve, reject) => {
    chrome.identity.getAuthToken({ interactive: true }, async (token) => {
      if (chrome.runtime.lastError || !token) return reject(new ApiError(0, "Google sign-in was cancelled."));
      try {
        await authenticate("/auth/google", { access_token: token });
        resolve();
      } catch (e) {
        reject(e);
      }
    });
  });
}
